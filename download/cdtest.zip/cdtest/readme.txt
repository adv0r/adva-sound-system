Come procedere:

Istruzioni per i possessori di PC
Di cosa si ha bisogno:
1) di molto spazio sull'hard disk: almeno 400 Mb
2) possibilmente di un processore veloce. Se avete un computer lento 
fate girare il programma di notte.
3) nient'altro

Per creare i file audio:
1) Decomprimere il file 'cdtest.zip'. Decomprimendo questo file si
creera' una nuova cartella dal nome 'cdtest'.
2) cercare nella cartella 'cdtest' il file '0.bat'
3) fare doppio click sul file '0.bat'
4) attendere che tutti i file di suono vengano creati
5) se avete una scheda audio potete ascoltare i file creati, basta
cliccare due volte sul file audio che volete ascoltare

Per masterizzare il cd:
1) aprire il programma per la masterizzazione
2) scegliere l'opzione "creazione cd audio"
3) selezionare i file audio da masterizzare. Se utilizzate l'ordine
presente nel file 'lista.txt' potrete anche controllare che i file
siano tutti presenti.
4) finito


